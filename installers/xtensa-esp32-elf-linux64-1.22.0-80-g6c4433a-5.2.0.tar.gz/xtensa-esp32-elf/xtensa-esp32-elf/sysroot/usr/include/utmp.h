#ifdef __cplusplus
extern "C" {
#endif
#include <sys/utmp.h>
#ifdef __cplusplus
}
#endif

